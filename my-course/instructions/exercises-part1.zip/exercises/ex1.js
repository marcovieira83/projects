const CryptoJS = require('crypto-js');

function hash(args) {
  // TODO
  // Vc deve concatenar os argumentos em uma string
  // Para facilitar no debug, separe cada elemento com um espaço em branco ' '
  // Utilize console.log para imprimir a string que será calculado o hash
  // Utilize CryptoJS.SHA256() para calcular o hash
  // Não se esqueca de converter para string o resultado

}

console.log(hash( ['Hello', 'BLOCKCHAIN', 'world!'] ));

//
// 5ec88e503d26cf513d3d3d33c5ff4c3dddffb7783b6fb7e664bbc97892afde2a
